#!/bin/bash
## https://speciationgenomics.github.io/filtering_vcfs/
## Extract INFO/DP into a tab-delimited annotation file
## Annotate a VCF v4.1 file 
# bcftools query -f '%CHROM\t%POS\t%DP\n' Challenge_data1.vcf | bgzip -c > Challenge_data1.vcf.annot.txt

##### COLUMNS ######################################################
## CHROM  POS  ID  REF  ALT  QUAL  FILTER  INFO  FORMAT  normal  vaf5

cd /Users/cmay/Desktop/variant_analysis/annovar

## Annovar Perl scripts
## Use the table_annovar.pl script to generate annotated tsv file from the VCF file.
## https://annovar.openbioinformatics.org/en/latest/user-guide/startup/

annotate_variation.pl -buildver hg19 -downdb -webfrom annovar refGene   humandb/
annotate_variation.pl -buildver hg19 -downdb cytoBand humandb/
annotate_variation.pl -buildver hg19 -downdb -webfrom annovar exac03    humandb/ 
annotate_variation.pl -buildver hg19 -downdb -webfrom annovar avsnp147  humandb/ 
annotate_variation.pl -buildver hg19 -downdb -webfrom annovar dbnsfp30a humandb/
table_annovar.pl Challenge_data1.vcf  humandb/ -buildver hg19  -out myanno -remove    \
                 -operation gx,r,f,f,f  -nastring . -xref example/gene_xref.txt       \
                 -protocol refGene,cytoBand,exac03,avsnp147,dbnsfp30a -csvout -polish \
                  

table_annovar.pl /Users/cmay/Desktop/variant_analysis/Challenge_data1.vcf           \
-buildver hg19 -out myanno_data1  -remove -operation g,r,f,f,f   humandb/           \
-protocol refGene,cytoBand,exac03,avsnp147,dbnsfp30a -nastring . -vcfinput -polish                                                         \


### Create a random sample to generate stats from 

## Set variables for vcfrandomsample
vcfrandomsample="/Users/cmay/bioinformatics/software/vcflib/bin/vcfrandomsample"
export PATH=$PATH:/Users/cmay/bioinformatics/software/vcflib/bin/vcfrandomsample

cd /Users/cmay/Desktop/variant_analysis

## Make a bed file from the vcf file
vcf2bed  --keep-header --do-not-sort < Challenge_data1.vcf > Challenge_data1.bed
sort-bed --tmpdir tmp Challenge_data1.bed > Challenge_data1.sorted.bed
bedtobam bedtobam -i Challenge_data1.sorted.bed  -g hg19.fa  > Challenge_data1.bam

### Pre-filtering with vcftools
## Quality filtering:  anything under Q20 or 99% accuracy
## MAF filter: 0.05 - 0.10 recommended cut-off
## Minimum depth filter: Ensure high quality calls
## Maximum depth filter: Remove false positives caused by multiple mapping
## Missing data: >25% missing data should be dropped

## Generate general statistics
bcftools view Challenge_data1.vcf  | wc -l

## Filter by MAF < 0.10
# vcftools --gzvcf Challenge_data1.vcf.gz --maf 0.10 --indv normal --out data1_norm.filt
# vcftools --gzvcf Challenge_data1.vcf.gz --maf 0.10 --indv vaf5   --out data1_vaf.filt

## Create a subsample dataset
bcftools view Challenge_data1.vcf | $vcfrandomsample -r 0.3 > data1_subset.vcf

## Compress vcf
bgzip data1_subset.vcf
# bgzip data1_norm.filt
# bgzip data1_vaf5.filt

## Index vcf
bcftools index data1_subset.vcf.gz
# bcftools index data1_norm_filt.vcf.gz
# bcftools index data1_norm_vaf5.vcf.gz

## Calculate allele frequency
vcftools --gzvcf data1_subset.vcf.gz  --freq2 --out data1_subset_freq.vcf      --max-alleles 2
# vcftools --gzvcf data1_norm_filt.vcf.gz --freq2 --out data1_norm_filt_freq.vcf   --max-alleles 2
# vcftools --gzvcf data1_vaf5_filt.vcf.gz --freq2 --out data1_vaf5_filt_freq.vcf   --max-alleles 2

## Calculate mean depth per individual
vcftools --gzvcf data1_subset.vcf.gz  --depth --out data1_subset_depth.vcf 
# vcftools --vcf data1_norm_filt.vcf   --depth --indv normal --out data1_norm_filt_depth
# vcftools --vcf data1_vaf5_filt.vcf   --depth --indv vaf5   --out data1_vaf5_filt_depth

## Calculate per site SNP quality  
vcftools --gzvcf data1_subset.vcf.gz      --site-quality --minGQ 20 --out data1_subset_quality
# vcftools --vcf data1_norm_filt_depth.vcf  --site-quality --minGQ 20 --indv normal --out data1_norm_filt_depth_quality
# vcftools --vcf data1_norm_filt_depth.vcf  --site-quality --minGQ 20 --indv vaf2   --out data1_vaf5_filt_depth_quality

# vcftools --gzvcf Challenge_data1.vcf.gz  --minGQ 20   \
#          --maf 0.10 --indv normal --minDP 20          \
#          --out Challenge_data1_norm.quality

# vcftools --gzvcf Challenge_data1.vcf.gz  --minGQ 20   \
#          --maf 0.10 --indv vaf5   --minDP 20          \
#          --out Challenge_data1_vaf5.quality

## min depth, max depth,  Missing data: >25% missing data should be dropped
