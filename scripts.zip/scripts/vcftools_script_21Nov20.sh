#!/bin/bash

cd /Users/cmay/bioinformatics/software
tar -xvf vcftools-vcftools-v0.1.16-18-g581c231.tar.gz

export vcftools=/Users/cmay/bioinformatics/software/vcftools581c231
export PERL5LIB=/usr/local/Cellar/perl/5.30.2_1/bin

cd /Users/cmay/bioinformatics/software/vcftools581c231

cd vcftools/

./configure
make
make install 
